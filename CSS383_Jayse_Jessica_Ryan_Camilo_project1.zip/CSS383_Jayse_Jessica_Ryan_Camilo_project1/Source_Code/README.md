# bioinfomatics-project-1
CSS 383 Bioinfomatics Project 1

Please clone the entire repo if you do not have a local copy/installation of BioPython. If you do have a local copy/installation the only required files are "project1.py" and "sequence.txt" ("asequences.txt" will be generated automatically

Compliation time ranges from 5-15 minutes for all alignemnts and figures. The parsimony and distance tree can take quite some time to generate and pop up and the Parsimony tree (second figure to pop up) may require that you close the distance tree figure before it will appear.
